# Recommendations & Health API

Base path: `/api/v1/me`

Health endpoints for financial wellness scoring and AI-powered action recommendations.

## GET /api/v1/me/health

Get financial health score with breakdown.

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "totalScore": 72,
    "maxScore": 100,
    "status": "GOOD",
    "portfolio-value": 10500000.00,
    "available-surplus": 3600000.00,
    "components": [
      {
        "componentName": "EMERGENCY_FUND",
        "label": "Emergency Fund",
        "score": 15,
        "maxScore": 20
      },
      {
        "componentName": "DIVERSIFICATION",
        "label": "Diversification",
        "score": 12,
        "maxScore": 20
      },
      {
        "componentName": "GOAL_PROGRESS",
        "label": "Goal Progress",
        "score": 18,
        "maxScore": 25
      },
      {
        "componentName": "SAVINGS_RATE",
        "label": "Savings Rate",
        "score": 15,
        "maxScore": 20
      },
      {
        "componentName": "RISK_ALIGNMENT",
        "label": "Risk Alignment",
        "score": 12,
        "maxScore": 15
      }
    ]
  },
  "message": "Service is healthy",
  "error": null
}
```

### Health Score Statuses

| Status | Range |
|--------|-------|
| `EXCELLENT` | 85-100 |
| `GOOD` | 65-84 |
| `FAIR` | 45-64 |
| `POOR` | 0-44 |

---

## POST /api/v1/me/recommendations

Generate AI-powered action recommendations based on user's financial profile and portfolio. Audited.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "id": "rec-uuid",
      "user_id": "user-uuid",
      "priority": "HIGH",
      "category": "ALLOCATION",
      "title": "Increase emergency fund allocation",
      "reason": "Your emergency fund covers only 2 months of expenses. Recommended target is 6 months.",
      "product_id": null,
      "product": null,
      "suggested_amount": 5000000.00,
      "goal_id": "goal-uuid",
      "goal": {
        "id": "goal-uuid",
        "name": "Emergency Fund",
        "type": "savings",
        "...": "..."
      },
      "recommended_allocation": {
        "type": "percentage",
        "value": 30
      },
      "status": "PENDING",
      "created_at": "2026-07-15 10:00:00",
      "updated_at": "2026-07-15 10:00:00",
      "resolved_at": null,
      "resolved_by_asset_id": null
    }
  ],
  "message": "Recommendations retrieved successfully",
  "error": null
}
```

### Recommendation Categories

| Category | Description |
|----------|-------------|
| `ALLOCATION` | Asset allocation suggestions |
| `GOAL` | Goal-related suggestions |
| `PRODUCT` | Product purchase suggestions |
| `DIVERSIFICATION` | Portfolio diversification |
| `EMERGENCY` | Emergency fund suggestions |
| `SAVINGS` | Savings improvement |

### Recommendation Priority

`HIGH`, `MEDIUM`, `LOW`

### Recommendation Status

`PENDING`, `ACTED_UPON`, `DISMISSED`, `EXPIRED`
