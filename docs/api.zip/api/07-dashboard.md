# Dashboard API

## GET /api/v1/admin/dashboard

Get admin dashboard summary with AUM, user stats, products, audit events, risk profile distribution, and AUM trend.

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "aum": 15000000000.00,
    "user_count": 250,
    "active_user_count": 180,
    "product_count": 45,
    "active_product_count": 40,
    "total_audit_events": 3200,
    "risk_profiles": {
      "risk_averse": 80,
      "moderate": 120,
      "risk_taker": 50
    },
    "aum_trend": [
      { "month": 1, "value": 12000000000.00 },
      { "month": 2, "value": 13000000000.00 },
      { "month": 3, "value": 15000000000.00 }
    ]
  },
  "message": "Dashboard data retrieved successfully",
  "error": null
}
```

---

## GET /api/v1/me/dashboard

Get user dashboard with portfolio summary and performance data.

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "portofolio": {
      "value": "Rp 10,500,000",
      "invested": "Rp 10,000,000",
      "holdings": 3,
      "items": [
        { "name": "Saham BBCA", "value": 5250000.00 },
        { "name": "Reksadana XYZ", "value": 3150000.00 },
        { "name": "Obligasi ABC", "value": 2100000.00 }
      ]
    },
    "performance": [
      { "month": 1, "value": 9500000.00 },
      { "month": 2, "value": 10000000.00 },
      { "month": 3, "value": 10500000.00 }
    ]
  },
  "message": "Dashboard data retrieved successfully",
  "error": null
}
```
