# Users API (Admin)

Base path: `/api/v1/users`

## GET /api/v1/users

Get paginated list of all users. Admin only.

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `search` | string | no | Search by name or email |
| `status` | string | no | Filter by status (ACTIVE/INACTIVE) |
| `page` | int | no | Page number (0-based, default 0) |
| `size` | int | no | Page size (default 20) |
| `sort` | string | no | Sort field and direction, e.g. `createdAt,desc` |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "content": [
      {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "name": "John Doe",
        "email": "user@example.com",
        "role": "USER",
        "status": "ACTIVE",
        "riskProfile": "moderate",
        "questionnaireCompleted": true,
        "createdAt": "2026-01-01T00:00:00Z",
        "updatedAt": "2026-06-15T12:00:00Z"
      }
    ],
    "page": 0,
    "size": 20,
    "totalElements": 1,
    "totalPages": 1
  },
  "message": "Users retrieved successfully",
  "error": null
}
```

---

## GET /api/v1/users/{id}

Get single user detail.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | User ID |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "John Doe",
    "email": "user@example.com",
    "role": "USER",
    "status": "ACTIVE",
    "riskProfile": "moderate",
    "questionnaireCompleted": true,
    "createdAt": "2026-01-01T00:00:00Z",
    "updatedAt": "2026-06-15T12:00:00Z"
  },
  "message": "User detail retrieved successfully",
  "error": null
}
```

### Error Responses

| Code | Message | Description |
|------|---------|-------------|
| 404 | User not found | Invalid user ID |

---

## PUT /api/v1/users/{id}

Update user status (activate/deactivate). Audited.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | User ID |

### Request Body

```json
{
  "status": "ACTIVE"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `status` | string | yes | `ACTIVE` or `INACTIVE` |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "id": "550e8400-...",
    "name": "John Doe",
    "email": "user@example.com",
    "role": "USER",
    "status": "ACTIVE",
    "createdAt": "2026-01-01T00:00:00Z",
    "updatedAt": "2026-07-15T12:00:00Z"
  },
  "message": "User updated successfully",
  "error": null
}
```
