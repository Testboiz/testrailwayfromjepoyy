# Authentication API

Base path: `/api/v1/auth`

## POST /api/v1/auth/login

Authenticate user credentials and return access + refresh tokens.

### Request Body

```json
{
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `email` | string | yes | Not blank |
| `password` | string | yes | Not blank, 8-72 chars |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "success": true,
    "message": "Login successful",
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600,
    "refreshToken": "dGhpcyBpcyBhIHJlZnJl...",
    "refreshExpiresIn": 604800,
    "user": {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "John Doe",
      "email": "user@example.com",
      "isAdmin": false,
      "questionnaireCompleted": false,
      "risk_profile": null
    }
  },
  "message": "Login successful",
  "error": null
}
```

### Error Responses

| Code | Message | Description |
|------|---------|-------------|
| 401 | Bad credentials | Email or password incorrect |

---

## POST /api/v1/auth/register

Create a new user account.

### Request Body

```json
{
  "name": "John Doe",
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `name` | string | yes | Not blank |
| `email` | string | yes | Not blank |
| `password` | string | yes | Not blank, 8-72 chars |

### Response 201 Created

```json
{
  "code": 201,
  "result": null,
  "message": "Registration successful",
  "error": null
}
```

### Error Responses

| Code | Message | Description |
|------|---------|-------------|
| 409 | Email already registered | Duplicate email |
| 400 | Validation errors | Missing/invalid fields |

---

## POST /api/v1/auth/logout

Invalidate current session / refresh token.

### Request Headers

| Header | Required | Description |
|--------|----------|-------------|
| `Authorization` | no | `Bearer <token>` — used to identify user for cleanup |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "success": true,
    "message": "Logout successful"
  },
  "message": "Logout successful",
  "error": null
}
```

---

## POST /api/v1/auth/refresh

Get a new access token using a refresh token.

### Request Body

```json
{
  "refreshToken": "dGhpcyBpcyBhIHJlZnJl..."
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `refreshToken` | string | yes | Not blank |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "success": true,
    "message": "Token refreshed successfully",
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600,
    "refreshToken": "bmV3IHJlZnJlc2ggdG9r...",
    "refreshExpiresIn": 604800
  },
  "message": "Token refreshed successfully",
  "error": null
}
```

### Error Responses

| Code | Message | Description |
|------|---------|-------------|
| 401 | Invalid/expired refresh token | Token not found or expired |
