# Risk Profiler API

Base path: `/api/v1/me/profiler`

## GET /api/v1/me/profiler

Get risk profiler questionnaire — list of questions with multiple-choice options and scores.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "question": "How would you react if your investment dropped 20% in a month?",
      "options": [
        {
          "key": "A",
          "label": "Sell everything immediately",
          "score": 1
        },
        {
          "key": "B",
          "label": "Wait and observe for a few months",
          "score": 2
        },
        {
          "key": "C",
          "label": "Buy more to average down",
          "score": 4
        },
        {
          "key": "D",
          "label": "Nothing, I'm in for the long term",
          "score": 5
        }
      ]
    }
  ],
  "message": "Risk profile retrieved successfully",
  "error": null
}
```

---

## PUT /api/v1/me/profiler

Submit risk profiler assessment answers. Audited.

### Request Body

```json
{
  "answers": [
    {
      "questionnaireAnswer": "C",
      "score": 4
    },
    {
      "questionnaireAnswer": "B",
      "score": 3
    }
  ]
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `answers` | array | yes | Not empty |
| `answers[].questionnaireAnswer` | string | no | Answer key |
| `answers[].score` | int | yes | 1-5 |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "id": "profiler-uuid",
    "risk_profile": "moderate",
    "questionnaire_completed": true,
    "updated_at": "2026-07-15T14:30:00Z",
    "score": 35
  },
  "message": "Risk profile updated successfully",
  "error": null
}
```

### Risk Profile Outcomes

| Score Range | Profile |
|-------------|---------|
| 0-20 | `risk_averse` |
| 21-35 | `moderate` |
| 36-50 | `risk_taker` |
