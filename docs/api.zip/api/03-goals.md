# Goals API

Base path: `/api/v1/me/goals`

## GET /api/v1/me/goals

Get all goals for authenticated user.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "id": "goal-uuid",
      "user_id": "user-uuid",
      "name": "Emergency Fund",
      "type": "savings",
      "target_amount": 50000000.00,
      "monthly_contribution": 5000000.00,
      "current_amount": 15000000.00,
      "target_date": "2026-12-31",
      "is_priority": true,
      "notes": "3 months of living expenses",
      "status": "ON_TRACK",
      "created_at": "2026-01-15 10:00:00",
      "updated_at": "2026-07-01 14:30:00",
      "projected-date": "2026-10-15",
      "recommended-contribution": 4500000.00
    }
  ],
  "message": "Goals retrieved successfully",
  "error": null
}
```

### Goal Types

`savings`, `vacation`, `vehicle`, `property`, `retirement`, `custom`

### Goal States

`ON_TRACK`, `BEHIND`, `ACHIEVED`, `AT_RISK`, `ARCHIVED`

---

## POST /api/v1/me/goals

Create a new goal. Audited.

### Request Body

```json
{
  "name": "Emergency Fund",
  "type": "savings",
  "target_amount": 50000000.00,
  "monthly_contribution": 5000000.00,
  "current_amount": 0.00,
  "target_date": "2026-12-31",
  "is_priority": true,
  "notes": "3 months living expenses"
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `name` | string | yes | Not blank |
| `type` | string | yes | One of: savings/vacation/vehicle/property/retirement/custom |
| `target_amount` | decimal | yes | ≥ 0.0, ≤ 100_000_000.00 |
| `monthly_contribution` | decimal | yes | ≥ 0.0 |
| `current_amount` | decimal | no | ≥ 0.0, default 0 |
| `target_date` | date (yyyy-MM-dd) | yes | Must be future |
| `is_priority` | boolean | yes | |
| `notes` | string | no | Max 1000 chars |

### Response 201 Created

```json
{
  "code": 201,
  "result": { "...goal object..." },
  "message": "Goal created successfully",
  "error": null
}
```

---

## PUT /api/v1/me/goals/{id}

Update an existing goal. Audited.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Goal ID |

### Request Body

```json
{
  "name": "Emergency Fund",
  "target_amount": 60000000.00,
  "monthly_contribution": 4000000.00,
  "current_amount": 15000000.00,
  "target_date": "2027-06-30",
  "is_priority": true,
  "notes": "Updated target for 6 months"
}
```

Fields same as create. All required except `current_amount`, `is_priority`, `notes`.

### Response 200 OK

Returns updated goal object.

### Error Responses

| Code | Message | Description |
|------|---------|-------------|
| 404 | Goal not found | ID invalid or not owned by user |
| 403 | Forbidden | Goal belongs to another user |

---

## DELETE /api/v1/me/goals/{id}

Delete a goal. Audited.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Goal ID |

### Response 200 OK

```json
{
  "code": 200,
  "result": null,
  "message": "Goal deleted successfully",
  "error": null
}
```

---

## GET /api/v1/me/goals/projections

Get goal projections with time-series data for all goals.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "id": "goal-uuid",
      "name": "Emergency Fund",
      "type": "savings",
      "target_amount": 50000000.00,
      "target_date": "2026-12-31",
      "is_priority": true,
      "notes": "...",
      "status": "ON_TRACK",
      "projected-date": "2026-10-15",
      "recommended-contribution": 4500000.00,
      "time-series": [
        { "month": 0, "value": 15000000.00 },
        { "month": 1, "value": 20000000.00 },
        { "month": 2, "value": 25000000.00 }
      ]
    }
  ],
  "message": "Goal projections retrieved successfully",
  "error": null
}
```

---

## POST /api/v1/me/goals/auto-allocate

Auto-allocate budget percentage across all goals. Audited.

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `percentage` | int | yes | Percentage of surplus to allocate (0-100) |

### Response 200 OK

Returns list of updated `GoalDTO` objects.

---

## GET /api/v1/me/goals/progress

Get detailed progress for all goals, including asset assignments and growth.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "goal_id": "goal-uuid",
      "goal_name": "Emergency Fund",
      "goal_type": "savings",
      "target_amount": 50000000.00,
      "current_saved": 15000000.00,
      "monthly_contribution": 5000000.00,
      "assigned_assets_count": 2,
      "total_potential_pnl": 500000.00,
      "total_potential_pnl_percent": 3.33,
      "avg_monthly_growth": 0.5,
      "projected_eta_months": 7,
      "is_priority": true
    }
  ],
  "message": "Goal progress fetched successfully",
  "error": null
}
```
