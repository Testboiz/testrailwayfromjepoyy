# Assets API

Base path: `/api/v1/me/assets`

## POST /api/v1/me/assets

Create a new asset (investment holding). Audited.

### Request Body

```json
{
  "product_id": "product-uuid",
  "units": 10.0,
  "amount": 5000000.00,
  "purchase_date": "2026-01-15 09:30:00",
  "platform": "Ajaib",
  "notes": "Initial investment"
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `product_id` | UUID | yes | Must exist |
| `units` | decimal | yes | > 0.0 |
| `amount` | decimal | yes | > 0.0 |
| `purchase_date` | datetime (yyyy-MM-dd HH:mm:ss) | yes | |
| `platform` | string | no | |
| `notes` | string | no | |

### Response 201 Created

```json
{
  "code": 201,
  "result": {
    "id": "asset-uuid",
    "productId": "product-uuid",
    "userId": "user-uuid",
    "units": 10.0,
    "amount": 5000000.00,
    "currentValue": 5250000.00,
    "purchaseDate": "2026-01-15T09:30:00Z",
    "platform": "Ajaib",
    "notes": "Initial investment",
    "createdAt": "...",
    "updatedAt": "..."
  },
  "message": "Asset created successfully",
  "error": null
}
```

---

## GET /api/v1/me/assets

Get all assets for authenticated user.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "id": "asset-uuid",
      "productId": "product-uuid",
      "userId": "user-uuid",
      "goalId": null,
      "units": 10.0,
      "amount": 5000000.00,
      "currentValue": 5250000.00,
      "purchaseDate": "2026-01-15T09:30:00Z",
      "platform": "Ajaib",
      "notes": null,
      "updatedAt": "2026-07-01T14:00:00Z"
    }
  ],
  "message": "Assets retrieved successfully",
  "error": null
}
```

---

## PUT /api/v1/me/assets/{id}

Update asset goal association. Audited.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Asset ID |

### Request Body

```json
{
  "goalId": "goal-uuid"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `goalId` | UUID | no | Goal to link asset to (null to unlink) |

### Response 200 OK

Returns updated `Asset` entity.

---

## DELETE /api/v1/me/assets/{id}

Delete an asset. Audited.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Asset ID |

### Response 200 OK

```json
{
  "code": 200,
  "result": null,
  "message": "Asset deleted successfully",
  "error": null
}
```

---

## POST /api/v1/me/assets/{assetId}/transactions

Execute a transaction (BUY/SELL) on an asset.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `assetId` | UUID | Asset ID |

### Request Body

```json
{
  "action": "BUY",
  "units": 5.0,
  "amount": 2500000.00,
  "transaction_date": "2026-07-01 10:00:00",
  "notes": "Additional purchase",
  "goal_id": "goal-uuid"
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `action` | enum | yes | `BUY` or `SELL` |
| `units` | decimal | no | > 0.0 |
| `amount` | decimal | no | > 0.0 |
| `transaction_date` | datetime | no | Defaults to now |
| `notes` | string | no | |
| `goal_id` | UUID | no | Link transaction to goal |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "assetId": "asset-uuid",
    "transactionId": "tx-uuid",
    "action": "BUY",
    "unitsTransacted": 5.0,
    "amountTransacted": 2500000.00,
    "remainingUnits": 15.0,
    "remainingValue": 7875000.00,
    "pnl": {
      "assetId": "...",
      "productId": "...",
      "productName": "Saham BBCA",
      "productType": "stock",
      "units": 15.0,
      "currentValue": 7875000.00,
      "avg_price": 500000.00,
      "potential_pnl": 375000.00,
      "potential_pnl_percent": 5.0,
      "realized_pnl": 250000.00,
      "realized_pnl_percent": 3.33
    }
  },
  "message": "Transaction executed successfully",
  "error": null
}
```

---

## GET /api/v1/me/assets/{assetId}/transactions

Get transaction history for a specific asset.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `assetId` | UUID | Asset ID |

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "id": "tx-uuid",
      "assetId": "asset-uuid",
      "action": "BUY",
      "units": 5.0,
      "price": 500000.00,
      "amount": 2500000.00,
      "transactionDate": "2026-07-01T10:00:00Z",
      "notes": "Additional purchase",
      "createdAt": "..."
    }
  ],
  "message": "Transaction logs retrieved successfully",
  "error": null
}
```

---

## GET /api/v1/me/assets/{assetId}/pnl

Get P&L details for a single asset.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `assetId` | UUID | Asset ID |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "assetId": "asset-uuid",
    "productId": "product-uuid",
    "productName": "Saham BBCA",
    "productType": "stock",
    "units": 15.0,
    "currentValue": 7875000.00,
    "avg_price": 500000.00,
    "potential_pnl": 375000.00,
    "potential_pnl_percent": 5.0,
    "realized_pnl": 250000.00,
    "realized_pnl_percent": 3.33
  },
  "message": "Assets retrieved successfully",
  "error": null
}
```

---

## PATCH /api/v1/me/assets/{assetId}/value

Update current market value of an asset.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `assetId` | UUID | Asset ID |

### Request Body

```json
{
  "current_value": 5400000.00,
  "notes": "Price update July 2026"
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `current_value` | decimal | yes | > 0.0 |
| `notes` | string | no | |

### Response 200 OK

Returns updated `Asset` entity.

---

## PATCH /api/v1/me/assets/{assetId}/goal

Update goal association for an asset (alternative to PUT).

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `assetId` | UUID | Asset ID |

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `goalId` | UUID | no | Goal ID to link (omit to unlink) |

### Response 200 OK

Returns updated `Asset` entity.

---

## GET /api/v1/me/assets/pnl

Get P&L summary for all assets.

### Response 200 OK

```json
{
  "code": 200,
  "result": [
    {
      "assetId": "asset-uuid",
      "productId": "product-uuid",
      "productName": "Saham BBCA",
      "productType": "stock",
      "units": 10.0,
      "currentValue": 5250000.00,
      "avg_price": 500000.00,
      "potential_pnl": 250000.00,
      "potential_pnl_percent": 5.0,
      "realized_pnl": 0.00,
      "realized_pnl_percent": 0.0
    }
  ],
  "message": "Assets retrieved successfully",
  "error": null
}
```

---

## GET /api/v1/me/assets/transaction-logs

Get all transaction logs for the authenticated user.

### Response 200 OK

Returns array of `TransactionHistory` entities.
