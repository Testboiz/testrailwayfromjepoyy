# Admin API

Base path: `/api/v1/admin`

## GET /api/v1/admin/audit

Get paginated audit logs.

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `headView` | boolean | no | Simplified head view (default false) |
| `page` | int | no | Page number |
| `size` | int | no | Page size |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "content": [
      {
        "id": "audit-uuid",
        "userId": "user-uuid",
        "action": "CREATE_GOAL",
        "category": "GOAL",
        "entityType": "Goal",
        "entityId": "entity-uuid",
        "details": { "name": "Emergency Fund" },
        "ipAddress": "192.168.1.1",
        "createdAt": "2026-07-01T10:00:00Z"
      }
    ],
    "page": 0,
    "size": 20,
    "totalElements": 50,
    "totalPages": 3
  },
  "message": "Audit logs retrieved successfully",
  "error": null
}
```

---

## GET /api/v1/admin/audit/search

Search audit logs with filters.

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `category` | string | no | Filter by category |
| `search` | string | no | Search in action/email/details |
| `from` | datetime (ISO) | no | Start date |
| `to` | datetime (ISO) | no | End date |
| `page` | int | no | Page number |
| `size` | int | no | Page size |

### Response 200 OK

Same structure as audit log list.

---

## GET /api/v1/admin/products

Get paginated product list (admin view, includes hidden).

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `search` | string | no | Search by name/code |
| `type` | string | no | Filter by product type |
| `page` | int | no | Page number |
| `size` | int | no | Page size |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "content": [
      {
        "id": "product-uuid",
        "code": "BBCA",
        "name": "Saham BBCA",
        "issuer": "PT Bank Central Asia Tbk",
        "type": "stock",
        "riskLevel": 2,
        "annualReturn": 12.5,
        "minInvestment": 100000.00,
        "currentPrice": 10500.00,
        "visible": true,
        "description": "Saham Bank Central Asia",
        "tenor": null,
        "lotSize": 100,
        "isFractionalAllowed": false,
        "createdAt": "...",
        "updatedAt": "..."
      }
    ],
    "...": "..."
  },
  "message": "Admin products retrieved successfully",
  "error": null
}
```

---

## POST /api/v1/admin/products

Create a new product (admin). Audited.

### Request Body

```json
{
  "code": "BBCA",
  "name": "Saham BBCA",
  "issuer": "PT Bank Central Asia Tbk",
  "type": "stock",
  "riskLevel": 2,
  "annualReturn": 12.5,
  "minInvestment": 100000.00,
  "currentPrice": 10500.00,
  "description": "Saham Bank Central Asia",
  "tenor": null,
  "lotSize": 100,
  "isFractionalAllowed": false,
  "visible": true
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `code` | string | yes | Not blank |
| `name` | string | yes | Not blank |
| `issuer` | string | yes | Not blank |
| `type` | string | yes | Not blank |
| `riskLevel` | int | yes | 1-5 |
| `annualReturn` | decimal | yes | ≥ 0.0 |
| `minInvestment` | decimal | yes | ≥ 0.0 |
| `currentPrice` | decimal | yes | ≥ 0.0 |
| `description` | string | yes | Not blank |
| `tenor` | string | no | |
| `lotSize` | int | yes | ≥ 1 |
| `isFractionalAllowed` | boolean | yes | |
| `visible` | boolean | yes | |

### Response 201 Created

```json
{
  "code": 201,
  "result": { "...product object..." },
  "message": "Admin product created successfully",
  "error": null
}
```

---

## PUT /api/v1/admin/products/{id}

Update an existing product (admin). Audited.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Product ID |

### Request Body

```json
{
  "name": "Saham BBCA Updated",
  "currentPrice": 10800.00,
  "visible": true
}
```

All fields optional. Only provided fields are updated.

### Response 200 OK

```json
{
  "code": 200,
  "result": { "...updated product..." },
  "message": "Admin product updated successfully",
  "error": null
}
```
