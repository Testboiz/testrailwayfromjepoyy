# Products API

Base path: `/api/v1/products`

## GET /api/v1/products

Get paginated list of available products (visible to user).

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `searchQuery` | string | no | Search by name or code |
| `type` | string | no | Filter by product type |
| `showAll` | boolean | no | Include hidden products (admin) |
| `dashboardSummary` | boolean | no | Return summary for dashboard |
| `page` | int | no | Page number |
| `size` | int | no | Page size |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "content": [
      {
        "id": "product-uuid",
        "code": "BBCA",
        "name": "Saham BBCA",
        "issuer": "PT Bank Central Asia Tbk",
        "type": "stock",
        "riskLevel": 2,
        "annualReturn": 12.5,
        "minInvestment": 100000.00,
        "currentPrice": 10500.00,
        "visible": true,
        "description": "Saham Bank Central Asia",
        "tenor": null,
        "lotSize": 100,
        "isFractionalAllowed": false,
        "createdAt": "2026-01-01T00:00:00Z",
        "updatedAt": "2026-06-01T00:00:00Z"
      }
    ],
    "page": 0,
    "size": 20,
    "totalElements": 1,
    "totalPages": 1
  },
  "message": "Products retrieved successfully",
  "error": null
}
```

---

## GET /api/v1/products/{id}

Get single product detail.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Product ID |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "id": "product-uuid",
    "code": "BBCA",
    "name": "Saham BBCA",
    "issuer": "PT Bank Central Asia Tbk",
    "type": "stock",
    "riskLevel": 2,
    "annualReturn": 12.5,
    "minInvestment": 100000.00,
    "currentPrice": 10500.00,
    "visible": true,
    "description": "Saham Bank Central Asia",
    "tenor": null,
    "lotSize": 100,
    "isFractionalAllowed": false,
    "createdAt": "2026-01-01T00:00:00Z",
    "updatedAt": "2026-06-01T00:00:00Z"
  },
  "message": "Product retreived successfully",
  "error": null
}
```

### Error Responses

| Code | Message | Description |
|------|---------|-------------|
| 404 | Product not found | Invalid product ID |

---

## PUT /api/v1/products/{id}

Toggle visibility of a product.

### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | UUID | Product ID |

### Request Body

```json
{
  "visibility": false
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `visibility` | boolean | yes | `true` = visible, `false` = hidden |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "id": "product-uuid",
    "code": "BBCA",
    "name": "Saham BBCA",
    "visible": false,
    "...": "..."
  },
  "message": "Product updated successfully",
  "error": null
}
```
