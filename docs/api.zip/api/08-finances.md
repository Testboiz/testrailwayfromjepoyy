# Finances API

Base path: `/api/v1/me/finances`

## GET /api/v1/me/finances

Get financial profile for authenticated user — income, expenses breakdown, auto-allocation settings.

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "id": "finance-uuid",
    "monthly_income": 15000000.00,
    "housing": 5000000.00,
    "food": 2500000.00,
    "transport": 1000000.00,
    "utilities": 800000.00,
    "healthcare": 500000.00,
    "entertainment": 700000.00,
    "insurance": 300000.00,
    "other": 600000.00,
    "total_expenses": 11400000.00,
    "auto_allocation_enabled": true,
    "priority_allocation_percentage": 50,
    "created_at": "2026-01-01 00:00:00",
    "updated_at": "2026-07-01 12:00:00"
  },
  "message": "Financial profile retrieved successfully",
  "error": null
}
```

### Expense Breakdown Fields

| Field | Type | Description |
|-------|------|-------------|
| `housing` | decimal | Housing/rent |
| `food` | decimal | Food & groceries |
| `transport` | decimal | Transportation |
| `utilities` | decimal | Utilities (electricity, water, internet) |
| `healthcare` | decimal | Healthcare |
| `entertainment` | decimal | Entertainment |
| `insurance` | decimal | Insurance premiums |
| `other` | decimal | Other expenses |
| `total_expenses` | decimal | Calculated sum of all expense fields |
| `monthly_income` | decimal | Income (same value as input) |

---

## PUT /api/v1/me/finances

Update financial profile. Audited. Triggers auto-allocation if enabled.

### Request Body

```json
{
  "monthly_income": 15000000.00,
  "expense": {
    "housing": 5000000.00,
    "food": 2500000.00,
    "transport": 1000000.00,
    "utilities": 800000.00,
    "healthcare": 500000.00,
    "entertainment": 700000.00,
    "insurance": 300000.00,
    "other": 600000.00
  },
  "auto_allocation_enabled": true,
  "priority_allocation_percentage": 50
}
```

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `monthly_income` | decimal | yes | ≥ 0.0 |
| `expense` | object | yes | Valid ExpenseDTO |
| `expense.housing` | decimal | yes | ≥ 0.0 |
| `expense.food` | decimal | yes | ≥ 0.0 |
| `expense.transport` | decimal | yes | ≥ 0.0 |
| `expense.utilities` | decimal | yes | ≥ 0.0 |
| `expense.healthcare` | decimal | yes | ≥ 0.0 |
| `expense.entertainment` | decimal | yes | ≥ 0.0 |
| `expense.insurance` | decimal | yes | ≥ 0.0 |
| `expense.other` | decimal | yes | ≥ 0.0 |
| `auto_allocation_enabled` | boolean | no | |
| `priority_allocation_percentage` | int | no | |

### Response 200 OK

```json
{
  "code": 200,
  "result": {
    "monthly_income": 15000000.00,
    "housing": 5000000.00,
    "food": 2500000.00,
    "transport": 1000000.00,
    "utilities": 800000.00,
    "healthcare": 500000.00,
    "entertainment": 700000.00,
    "insurance": 300000.00,
    "other": 600000.00,
    "total_expenses": 11400000.00,
    "auto_allocation_enabled": true,
    "priority_allocation_percentage": 50,
    "updated_at": "2026-07-15 14:00:00"
  },
  "message": "Financial profile updated successfully",
  "error": null
}
```
