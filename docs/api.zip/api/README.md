# Monarch WMS API Documentation

**Version:** 1.0.0  
**Base URL:** `http://localhost:8080` (development)  
**Protocol:** HTTP/REST  
**Format:** JSON  

## Authentication

Most endpoints require a Bearer JWT token.

### Getting a Token

```
POST /api/v1/auth/login
```

Include the returned `accessToken` in subsequent requests:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

### Token Expiry

| Token | Duration |
|-------|----------|
| Access Token | 1 hour |
| Refresh Token | 7 days |

Use `POST /api/v1/auth/refresh` to obtain a new access token before expiry.

---

## Response Format

All responses follow a uniform wrapper:

```json
{
  "code": 200,
  "result": { ... },
  "message": "Human-readable message",
  "error": null
}
```

| Field | Type | Description |
|-------|------|-------------|
| `code` | int | Business logic status code (mirrors HTTP) |
| `result` | T | Payload - single object, array, page, or null |
| `message` | string | Status description |
| `error` | Map | Error details (null on success) |

### Success Codes

| Code | Description |
|------|-------------|
| 200 | OK - Resource retrieved/updated/deleted |
| 201 | Created - Resource created |

### Error Codes

| Code | Description |
|------|-------------|
| 400 | Validation error / bad request |
| 401 | Unauthorized / missing token |
| 403 | Forbidden / insufficient role |
| 404 | Resource not found |
| 409 | Conflict (e.g. duplicate email) |
| 500 | Internal server error |

---

## Endpoint Summary

### Public

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/api/v1/auth/login` | Login | No |
| POST | `/api/v1/auth/register` | Register | No |
| POST | `/api/v1/auth/refresh` | Refresh token | No |

### User (authenticated)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/auth/logout` | Logout |
| GET | `/api/v1/me/goals` | List goals |
| POST | `/api/v1/me/goals` | Create goal |
| PUT | `/api/v1/me/goals/{id}` | Update goal |
| DELETE | `/api/v1/me/goals/{id}` | Delete goal |
| GET | `/api/v1/me/goals/projections` | Goal projections |
| POST | `/api/v1/me/goals/auto-allocate` | Auto-allocate |
| GET | `/api/v1/me/goals/progress` | Goal progress |
| GET | `/api/v1/me/assets` | List assets |
| POST | `/api/v1/me/assets` | Create asset |
| PUT | `/api/v1/me/assets/{id}` | Update asset goal |
| DELETE | `/api/v1/me/assets/{id}` | Delete asset |
| POST | `/api/v1/me/assets/{id}/transactions` | Execute transaction |
| GET | `/api/v1/me/assets/{id}/transactions` | Asset tx history |
| GET | `/api/v1/me/assets/{id}/pnl` | Asset P&L |
| PATCH | `/api/v1/me/assets/{id}/value` | Update market value |
| PATCH | `/api/v1/me/assets/{id}/goal` | Update asset goal |
| GET | `/api/v1/me/assets/pnl` | All assets P&L |
| GET | `/api/v1/me/assets/transaction-logs` | All tx logs |
| GET | `/api/v1/me/finances` | Get finances |
| PUT | `/api/v1/me/finances` | Update finances |
| GET | `/api/v1/me/health` | Health score |
| POST | `/api/v1/me/recommendations` | Generate recommendations |
| GET | `/api/v1/me/profiler` | Risk questionnaire |
| PUT | `/api/v1/me/profiler` | Submit assessment |
| GET | `/api/v1/me/dashboard` | User dashboard |

### Products (authenticated)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/products` | List products |
| GET | `/api/v1/products/{id}` | Product detail |
| PUT | `/api/v1/products/{id}` | Toggle visibility |

### Admin

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/users` | List users |
| GET | `/api/v1/users/{id}` | User detail |
| PUT | `/api/v1/users/{id}` | Update user status |
| GET | `/api/v1/admin/audit` | Audit logs |
| GET | `/api/v1/admin/audit/search` | Search audit logs |
| GET | `/api/v1/admin/products` | Admin product list |
| POST | `/api/v1/admin/products` | Create product |
| PUT | `/api/v1/admin/products/{id}` | Update product |
| GET | `/api/v1/admin/dashboard` | Admin dashboard |

---

## Endpoint Details

| # | File | Description |
|---|------|-------------|
| 1 | [Auth API](01-auth.md) | Login, register, logout, refresh token |
| 2 | [Users API](02-users.md) | User CRUD (admin) |
| 3 | [Goals API](03-goals.md) | Financial goals CRUD, projections, progress, auto-allocate |
| 4 | [Assets API](04-assets.md) | Investment assets, transactions, P&L, value updates |
| 5 | [Products API](05-products.md) | Product catalog browsing |
| 6 | [Admin API](06-admin.md) | Audit logs, product management |
| 7 | [Dashboard API](07-dashboard.md) | Admin & user dashboard |
| 8 | [Finances API](08-finances.md) | Income & expense profile |
| 9 | [Recommendations API](09-recommendations.md) | Health score & recommendations |
| 10 | [Risk Profiler API](10-risk-profiler.md) | Risk assessment questionnaire |
